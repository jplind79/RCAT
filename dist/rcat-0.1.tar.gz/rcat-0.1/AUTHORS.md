Authors and Contacts
====================

Main developers
---------------

* Petter Lind <petter.lind@smhi.se>
* David Lindstedt <david.lindstedt@smhi.se>

Contributors
------------

